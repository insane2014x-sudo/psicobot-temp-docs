# 🔧 INSTALACIÓN GD-XEAT PRO

## 🎯 REQUISITOS

### **Hardware:**
- ✅ CPU: Intel i5 o equivalente (mínimo)
- ✅ RAM: 8GB (recomendado 16GB)
- ✅ GPU: NVIDIA RTX 3060 (para transcripción rápida)
- ✅ Almacenamiento: 1TB disponible
- ✅ Impresora/escáner multifunción (opcional)

### **Software:**
- ✅ Windows 10/11, macOS 10.15+, Ubuntu 20.04+
- ✅ Python 3.10 o superior
- ✅ Git (para clonar repositorio)

## 🚀 INSTALACIÓN PASO A PASO

### **1. Clonar repositorio**
```bash
git clone https://github.com/insane2014x-sudo/GD-Xeat-Pro.git
cd GD-Xeat-Pro
```

### **2. Crear entorno virtual (recomendado)**
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Linux/Mac
python3 -m venv venv
source venv/bin/activate
```

### **3. Instalar dependencias**
```bash
pip install -r requirements.txt
```

**Nota:** Si tienes problemas con Whisper (dependencia grande ~1.5GB), puedes instalarlo después:
```bash
# Instalar primero las dependencias básicas
pip install flet sqlalchemy python-docx pandas pillow

# Luego Whisper (opcional para Fase 1)
pip install openai-whisper
```

### **4. Verificar instalación**
```bash
python src/ui/main.py
```

**Si todo está correcto**, debería abrirse una ventana del navegador con la interfaz de GD-XEAT Pro.

## 🐛 SOLUCIÓN DE PROBLEMAS

### **Problema: Error "No module named 'flet'"**
**Solución:**
```bash
pip install flet
```

### **Problema: Error con Whisper (CUDA/GPU)**
**Solución:** Instalar versión CPU primero:
```bash
pip install openai-whisper --no-deps
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118  # Para GPU
# o
pip install torch torchvision torchaudio  # Para CPU
```

### **Problema: Permisos en Linux/Mac**
**Solución:**
```bash
chmod +x venv/bin/activate
```

### **Problema: Espacio insuficiente**
**Solución:** Whisper requiere ~1.5GB. Liberar espacio o usar modelo más pequeño:
```python
# En src/core/config.py cambiar:
WHISPER_MODEL = "tiny"  # En lugar de "base"
```

## 📁 ESTRUCTURA DE DIRECTORIOS

Después de la instalación, deberías tener:
```
GD-Xeat-Pro/
├── venv/                 # Entorno virtual (creado)
├── data/                 # Datos del sistema (creado automáticamente)
│   ├── database/        # Base de datos SQLite
│   ├── audios/          # Grabaciones audiencias
│   ├── documentos/      # Documentos generados
│   └── plantillas/      # Plantillas Word
├── src/                 # Código fuente
└── requirements.txt     # Dependencias
```

## 🔧 CONFIGURACIÓN AVANZADA

### **Cambiar tema de interfaz**
Editar `src/core/config.py`:
```python
UI_THEME = "dark"  # light, dark, system
```

### **Cambiar tamaño de ventana**
```python
UI_WIDTH = 1400
UI_HEIGHT = 900
```

### **Usar modelo Whisper diferente**
```python
WHISPER_MODEL = "small"  # tiny, base, small, medium, large
```

## 🚀 EJECUCIÓN RÁPIDA

### **Método 1: Desde línea de comandos**
```bash
cd GD-Xeat-Pro
python src/ui/main.py
```

### **Método 2: Script de inicio (Windows)**
Crear archivo `iniciar.bat`:
```batch
@echo off
cd /d "C:\ruta\a\GD-Xeat-Pro"
call venv\Scripts\activate
python src/ui/main.py
pause
```

### **Método 3: Script de inicio (Linux/Mac)**
Crear archivo `iniciar.sh`:
```bash
#!/bin/bash
cd /ruta/a/GD-Xeat-Pro
source venv/bin/activate
python src/ui/main.py
```

## 📊 VERIFICACIÓN DE INSTALACIÓN

### **Prueba 1: Base de datos**
```bash
python -c "from src.core.database import init_db; init_db(); print('✅ Base de datos OK')"
```

### **Prueba 2: Configuración**
```bash
python -c "from src.core.config import config; print(f'✅ Config: {config.APP_NAME} v{config.APP_VERSION}')"
```

### **Prueba 3: Interfaz**
```bash
python src/ui/main.py
# Debería abrir navegador con interfaz
```

## 🔄 ACTUALIZACIÓN

### **Actualizar desde GitHub**
```bash
cd GD-Xeat-Pro
git pull origin main
pip install -r requirements.txt --upgrade
```

### **Actualizar base de datos (si hay cambios)**
```bash
python -c "from src.core.database import init_db; init_db()"
```

## 📞 SOPORTE

### **Problemas comunes:**
1. **Interfaz no se abre:** Verificar que FLET esté instalado correctamente
2. **Error base de datos:** Verificar permisos de escritura en carpeta `data/`
3. **Whisper lento:** Cambiar a modelo más pequeño (`tiny` o `base`)

### **Contacto:**
- **Telegram:** @ClawXeatJr (soporte técnico)
- **GitHub Issues:** https://github.com/insane2014x-sudo/GD-Xeat-Pro/issues

---
**Última actualización:** 21 Abril 2026  
**Versión:** 1.0.0