"""
Esquema de base de datos SQLAlchemy para GD-XEAT Pro
"""

from sqlalchemy import create_engine, Column, Integer, String, Text, Date, DateTime, Boolean, ForeignKey, Enum
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, sessionmaker
from datetime import datetime
import enum

from .config import config

# Base de datos
Base = declarative_base()
engine = create_engine(config.DATABASE_URL, echo=False)
SessionLocal = sessionmaker(bind=engine)

# Enumeraciones
class EstadoAudiencia(enum.Enum):
    PROGRAMADA = "programada"
    REALIZADA = "realizada"
    CANCELADA = "cancelada"
    APLAZADA = "aplazada"

class TipoPersona(enum.Enum):
    AGRAVIADO = "agraviado"
    DENUNCIADO = "denunciado"
    TESTIGO = "testigo"
    ABOGADO = "abogado"
    PERITO = "perito"
    OTRO = "otro"

class TipoDocumento(enum.Enum):
    ACTA_ENTREVISTA = "acta_entrevista"
    ACTA_LACRADO = "acta_lacrado"
    ACTA_INCONCURRENCIA = "acta_inconcurrencia"
    CADENA_CUSTODIA = "cadena_custodia"
    OFICIO = "oficio"
    INFORME = "informe"
    OTRO = "otro"

class TipoOficio(enum.Enum):
    ENTRANTE = "entrante"
    SALIENTE = "saliente"

# Modelos de datos
class Expediente(Base):
    """Expediente judicial"""
    __tablename__ = "expedientes"
    
    id = Column(Integer, primary_key=True)
    numero = Column(String(100), unique=True, nullable=False, index=True)
    materia = Column(String(200))
    delito = Column(String(200))
    lugar_hechos = Column(String(300))
    fecha_apertura = Column(Date)
    fecha_cierre = Column(Date, nullable=True)
    observaciones = Column(Text)
    activo = Column(Boolean, default=True)
    fecha_creacion = Column(DateTime, default=datetime.now)
    fecha_actualizacion = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    
    # Relaciones
    audiencias = relationship("Audiencia", back_populates="expediente", cascade="all, delete-orphan")
    documentos = relationship("Documento", back_populates="expediente", cascade="all, delete-orphan")
    personas = relationship("PersonaExpediente", back_populates="expediente", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<Expediente {self.numero}>"


class Persona(Base):
    """Personas involucradas en expedientes"""
    __tablename__ = "personas"
    
    id = Column(Integer, primary_key=True)
    dni = Column(String(20), unique=True, nullable=True)
    nombres = Column(String(200), nullable=False)
    apellidos = Column(String(200), nullable=False)
    tipo = Column(Enum(TipoPersona), default=TipoPersona.OTRO)
    edad = Column(Integer, nullable=True)
    direccion = Column(String(300))
    telefono = Column(String(50))
    email = Column(String(200))
    observaciones = Column(Text)
    activo = Column(Boolean, default=True)
    fecha_creacion = Column(DateTime, default=datetime.now)
    
    # Relaciones
    expedientes = relationship("PersonaExpediente", back_populates="persona", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<Persona {self.nombres} {self.apellidos}>"
    
    @property
    def nombre_completo(self):
        return f"{self.nombres} {self.apellidos}"


class PersonaExpediente(Base):
    """Relación muchos-a-muchos entre Personas y Expedientes"""
    __tablename__ = "personas_expedientes"
    
    id = Column(Integer, primary_key=True)
    persona_id = Column(Integer, ForeignKey("personas.id"), nullable=False)
    expediente_id = Column(Integer, ForeignKey("expedientes.id"), nullable=False)
    rol = Column(String(100))  # Agraviado principal, Denunciado, Testigo, etc.
    observaciones = Column(Text)
    
    # Relaciones
    persona = relationship("Persona", back_populates="expedientes")
    expediente = relationship("Expediente", back_populates="personas")
    
    def __repr__(self):
        return f"<PersonaExpediente persona:{self.persona_id} expediente:{self.expediente_id}>"


class Audiencia(Base):
    """Audiencias programadas/realizadas"""
    __tablename__ = "audiencias"
    
    id = Column(Integer, primary_key=True)
    expediente_id = Column(Integer, ForeignKey("expedientes.id"), nullable=False)
    fecha_hora = Column(DateTime, nullable=False)
    duracion_minutos = Column(Integer, default=60)
    sala = Column(String(100))
    estado = Column(Enum(EstadoAudiencia), default=EstadoAudiencia.PROGRAMADA)
    observaciones = Column(Text)
    audio_path = Column(String(500), nullable=True)  # Ruta al archivo de audio
    transcripcion_path = Column(String(500), nullable=True)  # Ruta a transcripción
    fecha_creacion = Column(DateTime, default=datetime.now)
    fecha_actualizacion = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    
    # Relaciones
    expediente = relationship("Expediente", back_populates="audiencias")
    documentos = relationship("Documento", back_populates="audiencia", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<Audiencia {self.fecha_hora} - {self.estado.value}>"


class Juez(Base):
    """Jueces y sus especialidades"""
    __tablename__ = "jueces"
    
    id = Column(Integer, primary_key=True)
    nombre_completo = Column(String(200), unique=True, nullable=False)
    especialidad = Column(String(100))
    juzgado = Column(String(200))
    activo = Column(Boolean, default=True)
    fecha_creacion = Column(DateTime, default=datetime.now)
    
    def __repr__(self):
        return f"<Juez {self.nombre_completo}>"


class Documento(Base):
    """Documentos generados (actas, oficios, etc.)"""
    __tablename__ = "documentos"
    
    id = Column(Integer, primary_key=True)
    expediente_id = Column(Integer, ForeignKey("expedientes.id"), nullable=False)
    audiencia_id = Column(Integer, ForeignKey("audiencias.id"), nullable=True)
    tipo = Column(Enum(TipoDocumento), nullable=False)
    titulo = Column(String(300), nullable=False)
    descripcion = Column(Text)
    archivo_path = Column(String(500), nullable=False)  # Ruta al archivo .docx/.pdf
    plantilla_usada = Column(String(200))
    fecha_generacion = Column(DateTime, default=datetime.now)
    fecha_creacion = Column(DateTime, default=datetime.now)
    
    # Relaciones
    expediente = relationship("Expediente", back_populates="documentos")
    audiencia = relationship("Audiencia", back_populates="documentos")
    
    def __repr__(self):
        return f"<Documento {self.titulo} ({self.tipo.value})>"


class Oficio(Base):
    """Oficios entrantes y salientes"""
    __tablename__ = "oficios"
    
    id = Column(Integer, primary_key=True)
    tipo = Column(Enum(TipoOficio), nullable=False)
    numero = Column(String(100), nullable=False)
    remitente = Column(String(300))
    destinatario = Column(String(300))
    asunto = Column(String(500), nullable=False)
    contenido = Column(Text)
    fecha_recepcion = Column(DateTime, nullable=True)
    fecha_envio = Column(DateTime, nullable=True)
    estado = Column(String(50), default="pendiente")  # pendiente, enviado, recibido, archivado
    archivo_path = Column(String(500), nullable=True)
    expediente_id = Column(Integer, ForeignKey("expedientes.id"), nullable=True)
    observaciones = Column(Text)
    fecha_creacion = Column(DateTime, default=datetime.now)
    fecha_actualizacion = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    
    # Relaciones
    expediente = relationship("Expediente")
    
    def __repr__(self):
        return f"<Oficio {self.numero} ({self.tipo.value})>"


class Usuario(Base):
    """Usuarios del sistema (para futuro multi-usuario)"""
    __tablename__ = "usuarios"
    
    id = Column(Integer, primary_key=True)
    username = Column(String(100), unique=True, nullable=False)
    nombre_completo = Column(String(200), nullable=False)
    email = Column(String(200), unique=True)
    rol = Column(String(50), default="usuario")  # administrador, usuario, auditor
    activo = Column(Boolean, default=True)
    fecha_creacion = Column(DateTime, default=datetime.now)
    fecha_ultimo_acceso = Column(DateTime, nullable=True)
    
    def __repr__(self):
        return f"<Usuario {self.username}>"


# Funciones de utilidad para la base de datos
def init_db():
    """Inicializa la base de datos creando todas las tablas"""
    # Asegurar que existe el directorio de base de datos
    config.inicializar_directorios()
    
    # Crear todas las tablas
    Base.metadata.create_all(bind=engine)
    
    print("✅ Base de datos inicializada correctamente")
    print(f"📁 Archivo: {config.DATABASE_FILE}")
    
    # Crear sesión para posibles datos iniciales
    session = SessionLocal()
    
    try:
        # Verificar si hay datos iniciales necesarios
        # (Por ejemplo, usuario administrador por defecto)
        pass
        
        session.commit()
        print("✅ Datos iniciales verificados")
        
    except Exception as e:
        session.rollback()
        print(f"⚠️  Error en datos iniciales: {e}")
    
    finally:
        session.close()
    
    return True


def get_session():
    """Obtiene una nueva sesión de base de datos"""
    return SessionLocal()


if __name__ == "__main__":
    # Prueba de inicialización
    print("🧪 INICIALIZANDO BASE DE DATOS GD-XEAT PRO")
    print("=" * 50)
    
    init_db()
    
    # Mostrar información de las tablas creadas
    from sqlalchemy import inspect
    inspector = inspect(engine)
    
    print("\n📊 TABLAS CREADAS:")
    for table_name in inspector.get_table_names():
        print(f"  📋 {table_name}")
    
    print("\n✅ Base de datos lista para usar")