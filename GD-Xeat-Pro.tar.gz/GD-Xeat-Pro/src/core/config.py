"""
Configuración del sistema GD-XEAT Pro
"""

import os
from pathlib import Path

# Directorio base del proyecto
BASE_DIR = Path(__file__).parent.parent.parent

# Configuración de rutas
class Config:
    # Rutas de datos
    DATA_DIR = BASE_DIR / "data"
    DATABASE_DIR = DATA_DIR / "database"
    AUDIOS_DIR = DATA_DIR / "audios"
    DOCUMENTOS_DIR = DATA_DIR / "documentos"
    PLANTILLAS_DIR = DATA_DIR / "plantillas"
    BACKUPS_DIR = BASE_DIR / "backups"
    
    # Archivos de base de datos
    DATABASE_FILE = DATABASE_DIR / "gdxeat.db"
    DATABASE_URL = f"sqlite:///{DATABASE_FILE}"
    
    # Configuración de la aplicación
    APP_NAME = "GD-XEAT Pro"
    APP_VERSION = "1.0.0"
    APP_DESCRIPTION = "Sistema de Gestión Judicial Digital"
    
    # Configuración de interfaz
    UI_THEME = "light"  # light, dark, system
    UI_WIDTH = 1200
    UI_HEIGHT = 800
    
    # Configuración de documentos
    DEFAULT_PLANTILLA_ACTA = "acta_entrevista.docx"
    DEFAULT_PLANTILLA_OFICIO = "oficio_judicial.docx"
    
    # Configuración de transcripción
    WHISPER_MODEL = "base"  # tiny, base, small, medium, large
    TRANSCRIPCION_TIMEOUT = 3600  # segundos (1 hora)
    
    # Configuración de backup
    BACKUP_AUTOMATICO = True
    BACKUP_INTERVALO_HORAS = 24
    
    @classmethod
    def inicializar_directorios(cls):
        """Crea todos los directorios necesarios si no existen"""
        directorios = [
            cls.DATA_DIR,
            cls.DATABASE_DIR,
            cls.AUDIOS_DIR,
            cls.DOCUMENTOS_DIR,
            cls.PLANTILLAS_DIR,
            cls.BACKUPS_DIR,
        ]
        
        for directorio in directorios:
            directorio.mkdir(parents=True, exist_ok=True)
            print(f"✅ Directorio creado/verificado: {directorio}")
        
        return True
    
    @classmethod
    def get_config_info(cls):
        """Obtiene información de configuración para debugging"""
        return {
            "app_name": cls.APP_NAME,
            "app_version": cls.APP_VERSION,
            "database_file": str(cls.DATABASE_FILE),
            "database_exists": cls.DATABASE_FILE.exists(),
            "directorios_creados": all(d.exists() for d in [
                cls.DATA_DIR, cls.DATABASE_DIR, cls.AUDIOS_DIR,
                cls.DOCUMENTOS_DIR, cls.PLANTILLAS_DIR, cls.BACKUPS_DIR
            ])
        }


# Instancia global de configuración
config = Config()

if __name__ == "__main__":
    # Prueba de configuración
    print(f"🔧 CONFIGURACIÓN GD-XEAT PRO v{config.APP_VERSION}")
    print("=" * 50)
    
    config.inicializar_directorios()
    
    info = config.get_config_info()
    for key, value in info.items():
        print(f"{key:20}: {value}")
    
    print("\n✅ Configuración inicializada correctamente")