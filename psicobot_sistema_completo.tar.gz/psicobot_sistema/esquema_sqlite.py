#!/usr/bin/env python3
"""
Esquema de base de datos SQLite para sistema Psicobot
"""

import sqlite3
import json
from datetime import datetime

def crear_base_datos(ruta_db='psicobot.db'):
    """Crea la base de datos SQLite con todas las tablas"""
    
    conn = sqlite3.connect(ruta_db)
    cursor = conn.cursor()
    
    # Tabla 1: participantes
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS participantes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tipo TEXT NOT NULL,
        nombres TEXT NOT NULL,
        apellidos TEXT NOT NULL,
        dni TEXT UNIQUE,
        fecha_nacimiento DATE,
        edad INTEGER,
        sexo TEXT,
        estado_civil TEXT,
        ocupacion TEXT,
        domicilio TEXT,
        lugar_nacimiento TEXT,
        telefono TEXT,
        email TEXT,
        nombre_padre TEXT,
        nombre_madre TEXT,
        vinculo TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    ''')
    
    # Tabla 2: citas (del Excel)
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS citas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        numero_cita INTEGER,
        mes TEXT,
        numero_cg TEXT,
        fecha_programada DATE,
        hora_programada TIME,
        estado TEXT,
        persona_solicitante TEXT,
        responsable_programacion TEXT,
        fecha_solicitud DATE,
        via_solicitud TEXT,
        numero_oficio TEXT,
        numero_caso TEXT,
        autoridad_solicitante TEXT,
        validacion_dia_semana TEXT,
        validacion_feriado TEXT,
        unidad_medida_legal TEXT,
        tipo_diligencia TEXT,
        modalidad TEXT,
        lugar_ejecucion TEXT,
        direccion TEXT,
        distrito TEXT,
        provincia TEXT,
        departamento TEXT,
        solicitante_representante TEXT,
        cargo_solicitante TEXT,
        institucion_solicitante TEXT,
        direccion_solicitante TEXT,
        telefono_solicitante TEXT,
        email_solicitante TEXT,
        observaciones_solicitud TEXT,
        fecha_notificacion DATE,
        medio_notificacion TEXT,
        observaciones_notificacion TEXT,
        fecha_ejecucion DATE,
        hora_ejecucion TIME,
        duracion_estimada TEXT,
        recursos_requeridos TEXT,
        observaciones_ejecucion TEXT,
        imported_from_excel BOOLEAN DEFAULT TRUE,
        excel_row_number INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    ''')
    
    # Tabla 3: sesiones
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS sesiones (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        cita_id INTEGER REFERENCES citas(id),
        fecha_real DATE,
        hora_inicio TIME,
        hora_termino TIME,
        lugar TEXT,
        psicologa_id INTEGER REFERENCES participantes(id),
        juez_id INTEGER REFERENCES participantes(id),
        fiscal_penal_id INTEGER REFERENCES participantes(id),
        fiscal_familia_id INTEGER REFERENCES participantes(id),
        abogado_id INTEGER REFERENCES participantes(id),
        denunciado_id INTEGER REFERENCES participantes(id),
        agraviado_id INTEGER REFERENCES participantes(id),
        acompanante_menor_id INTEGER REFERENCES participantes(id),
        tipo_delito TEXT,
        tipo_participacion TEXT,
        tipo_defensa TEXT,
        observaciones TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    ''')
    
    # Tabla 4: documentos
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS documentos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sesion_id INTEGER REFERENCES sesiones(id),
        tipo_documento TEXT NOT NULL,
        plantilla_original TEXT,
        documento_generado TEXT,
        campos_rellenados TEXT,  -- JSON como texto
        estado TEXT DEFAULT 'generado',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    ''')
    
    # Tabla 5: audios
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS audios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sesion_id INTEGER REFERENCES sesiones(id),
        ruta_archivo TEXT NOT NULL,
        duracion_segundos INTEGER,
        formato TEXT,
        tamano_bytes INTEGER,
        fecha_grabacion TIMESTAMP,
        calidad TEXT,
        transcripcion_id INTEGER REFERENCES transcripciones(id),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    ''')
    
    # Tabla 6: transcripciones
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS transcripciones (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        audio_id INTEGER REFERENCES audios(id),
        texto_completo TEXT,
        texto_formateado TEXT,
        duracion_procesamiento INTEGER,
        modelo_usado TEXT,
        confianza_promedio REAL,
        estado TEXT DEFAULT 'pendiente',
        revisado_por TEXT,
        fecha_revision DATE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    ''')
    
    # Índices para mejor rendimiento
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_citas_numero_caso ON citas(numero_caso)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_citas_fecha_programada ON citas(fecha_programada)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_participantes_dni ON participantes(dni)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_sesiones_cita_id ON sesiones(cita_id)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_documentos_sesion_id ON documentos(sesion_id)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_audios_sesion_id ON audios(sesion_id)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_transcripciones_audio_id ON transcripciones(audio_id)')
    
    conn.commit()
    
    # Verificar tablas creadas
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tablas = cursor.fetchall()
    
    print("✅ Base de datos creada exitosamente")
    print(f"📊 Tablas creadas: {len(tablas)}")
    for tabla in tablas:
        print(f"  • {tabla[0]}")
    
    conn.close()
    return ruta_db

def mostrar_esquema(ruta_db='psicobot.db'):
    """Muestra el esquema completo de la base de datos"""
    conn = sqlite3.connect(ruta_db)
    cursor = conn.cursor()
    
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tablas = cursor.fetchall()
    
    print("📋 ESQUEMA DE BASE DE DATOS:")
    print("=" * 50)
    
    for tabla in tablas:
        nombre_tabla = tabla[0]
        print(f"\n📊 TABLA: {nombre_tabla}")
        print("-" * 30)
        
        cursor.execute(f"PRAGMA table_info({nombre_tabla})")
        columnas = cursor.fetchall()
        
        for col in columnas:
            col_id, col_nombre, col_tipo, not_null, default_val, pk = col
            print(f"  {col_nombre:25} {col_tipo:15} {'PK' if pk else ''} {'NOT NULL' if not_null else ''}")
    
    conn.close()

if __name__ == "__main__":
    print("🧠 CREANDO ESQUEMA DE BASE DE DATOS PSICOBOT")
    print("=" * 50)
    
    # Crear base de datos
    db_path = crear_base_datos()
    
    # Mostrar esquema
    mostrar_esquema(db_path)
    
    print("\n🎯 Base de datos lista para usar en:", db_path)
    print("💾 Tamaño aproximado: 6 tablas, ~50 columnas totales")