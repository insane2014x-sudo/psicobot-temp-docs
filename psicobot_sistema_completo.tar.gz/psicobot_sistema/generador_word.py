#!/usr/bin/env python3
"""
Generador de documentos Word para sistema Psicobot
Usa docxtpl (como tu script actual) pero conectado a SQLite
"""

from docxtpl import DocxTemplate
import sqlite3
import os
from datetime import datetime
import pandas as pd

class GeneradorDocumentos:
    def __init__(self, db_path='psicobot_sistema/psicobot.db'):
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path)
        
    def obtener_datos_cita(self, cita_id):
        """Obtiene datos de una cita específica desde SQLite"""
        cursor = self.conn.cursor()
        
        cursor.execute("""
            SELECT numero_cita, fecha_programada, hora_programada, 
                   persona_solicitante, numero_caso, autoridad_solicitante
            FROM citas 
            WHERE id = ?
        """, (cita_id,))
        
        cita = cursor.fetchone()
        
        if not cita:
            return None
        
        # Convertir a diccionario
        datos = {
            'numero_cita': cita[0],
            'fecha_programada': cita[1],
            'hora_programada': cita[2],
            'persona_solicitante': cita[3],
            'numero_caso': cita[4],
            'autoridad_solicitante': cita[5]
        }
        
        return datos
    
    def crear_contexto_ejemplo(self):
        """
        Crea contexto de ejemplo para la plantilla Word
        Con datos ficticios pero realistas
        """
        # Fecha y hora actual
        ahora = datetime.now()
        
        contexto = {
            # Campos de expediente/documento
            'EXPEDIENTE': '2026-00123-PE',
            
            # Campos de fecha/hora
            'HORA_INICIO': '09:00:00',
            'HORA DE TÉRMINO DE DILIGENCIA': '10:30:00',
            'FECHA  AGRAVIADO': ahora.strftime('%d/%m/%Y'),
            
            # Campos de personas (jueces, fiscales, etc.)
            'NOMBRE JUEZ': 'DR. JUAN PÉREZ GARCÍA',
            'EL O LA JUEZ': 'EL JUEZ',
            'NOMBRE DEL JUZGADO': 'JUZGADO DE FAMILIA DE LA MERCED',
            'NOMBRE DEL FISCAL PENAL': 'FISCAL MARÍA LÓPEZ RUIZ',
            'NOMBRE DEL FISCAL FAMILIA': 'FISCAL CARLOS MARTÍNEZ SOTO',
            'PROCEDENCIA DE FISCAL': 'FISCALÍA PENAL DE CHANCHAMAYO',
            'NOMBRE DEL ABOGADO': 'ABG. ROBERTO DÍAZ MENDIETA',
            'CASILLA ELECTRONICA ABOGADO': 'abogado@ejemplo.com',
            'NOMBRE DE PSICOLOGA': 'PSIC. ANA TORRES VARGAS',
            'NOMBRE ESPECIALISTA': 'ESP. LUIS FERNÁNDEZ CASTRO',
            
            # Campos de denunciado
            'NOMBRE DENUNCIADO': 'MANUEL GUTIÉRREZ ROJAS',
            
            # Campos de agraviado
            'INICICIALES AGRAVIADO': 'M.P.R.',
            'EDAD AGRAVIADO': '32',
            'SEXO AGRAVIADO': 'FEMENINO',
            'DNI DE AGRAVIADO': '87654321',
            'LUGAR DE NACIMIENTO': 'LA MERCED, CHANCHAMAYO',
            'DOMICILIO ACTUAL': 'AV. PROGRESO 123 - LA MERCED',
            'OCUPACION ACTUAL': 'DOCENTE',
            'NRO DE CELULAR': '987654321',
            'NOMBRE DE PADRE': 'PEDRO RAMÍREZ CASTILLO',
            'NOMBRE DE MADRE': 'MARÍA RAMÍREZ SÁNCHEZ',
            
            # Campos de acompañante menor
            'NOMBRE DE ACOMPAÑANTE MENOR': 'SOFÍA GUTIÉRREZ RAMÍREZ',
            'EDAD  DE ACOMPAÑANTE MENOR': '8',
            'DNI  DE ACOMPAÑANTE MENOR': '12345678',
            'ESTADO CIVIL  DE ACOMPAÑANTE MENOR': 'SOLTERA',
            'DOMICILIO DE ACOMPAÑANTE MENOR': 'AV. PROGRESO 123 - LA MERCED',
            'GRADO MENOR': '3er GRADO',
            'NUMERO DE ACOMPAÑANTE MENOR': '987654322',
            'VINCULO DE ACOMPAÑANTE MENOR': 'HIJA',
            
            # Campos legales
            'TIPO_DELITO': 'VIOLENCIA FAMILIAR',
            'TIPO_PARTICIPACION': 'VÍCTIMA',
            'TIPO DE DEFENSA': 'DEFENSORÍA PÚBLICA',
            'VINCULO': 'EX PAREJA'
        }
        
        return contexto
    
    def generar_documento(self, plantilla_path, contexto, output_path):
        """
        Genera documento Word a partir de plantilla y contexto
        
        Args:
            plantilla_path: Ruta a plantilla .docx
            contexto: Diccionario con campos a reemplazar
            output_path: Ruta donde guardar documento generado
        """
        try:
            print(f"📄 Cargando plantilla: {plantilla_path}")
            doc = DocxTemplate(plantilla_path)
            
            print(f"🔧 Rellenando {len(contexto)} campos...")
            doc.render(contexto)
            
            print(f"💾 Guardando documento: {output_path}")
            doc.save(output_path)
            
            # Verificar que se guardó
            if os.path.exists(output_path):
                tamano = os.path.getsize(output_path)
                print(f"✅ Documento generado exitosamente ({tamano:,} bytes)")
                return True
            else:
                print("❌ Error: Documento no se guardó correctamente")
                return False
                
        except Exception as e:
            print(f"❌ Error generando documento: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def generar_desde_cita(self, cita_id, plantilla_path, output_dir):
        """
        Genera documento para una cita específica
        """
        print(f"\n🧠 GENERANDO DOCUMENTO PARA CITA ID: {cita_id}")
        print("=" * 50)
        
        # Obtener datos de la cita
        datos_cita = self.obtener_datos_cita(cita_id)
        if not datos_cita:
            print(f"❌ No se encontró cita con ID: {cita_id}")
            return False
        
        print(f"📅 Cita #{datos_cita['numero_cita']}")
        print(f"   Fecha: {datos_cita['fecha_programada']}")
        print(f"   Solicitante: {datos_cita['persona_solicitante']}")
        print(f"   Caso: {datos_cita['numero_caso']}")
        
        # Crear contexto combinando datos reales y ejemplo
        contexto = self.crear_contexto_ejemplo()
        
        # Agregar datos reales de la cita al contexto
        contexto.update({
            'EXPEDIENTE': datos_cita['numero_caso'] or '2026-00123-PE',
            'HORA_INICIO': datos_cita['hora_programada'] or '09:00:00',
            # Podríamos mapear más campos según corresponda
        })
        
        # Crear nombre de archivo
        nombre_archivo = f"Acta_Entrevista_Cita{datos_cita['numero_cita']}_{datos_cita['persona_solicitante'][:20] if datos_cita['persona_solicitante'] else 'SinNombre'}.docx"
        nombre_archivo = nombre_archivo.replace(' ', '_').replace('/', '-')
        output_path = os.path.join(output_dir, nombre_archivo)
        
        # Generar documento
        return self.generar_documento(plantilla_path, contexto, output_path)
    
    def cerrar(self):
        """Cierra conexión a base de datos"""
        self.conn.close()

def main():
    """Función principal para probar el generador"""
    print("🖨️  GENERADOR DE DOCUMENTOS PSICOBOT")
    print("=" * 50)
    
    # Configuración
    db_path = 'psicobot_sistema/psicobot.db'
    plantilla_path = '/root/.openclaw/media/inbound/A.A.A.A---46e0dd0d-4e26-47a5-aa90-d6fbe89963d7.docx'
    output_dir = '/tmp/psicobot_documentos'
    
    # Crear directorio de salida
    os.makedirs(output_dir, exist_ok=True)
    
    # Crear generador
    generador = GeneradorDocumentos(db_path)
    
    # Obtener primera cita disponible
    cursor = generador.conn.cursor()
    cursor.execute("SELECT id, numero_cita FROM citas LIMIT 1")
    primera_cita = cursor.fetchone()
    
    if not primera_cita:
        print("⚠️  No hay citas en la base de datos. Usando datos de ejemplo.")
        
        # Generar con datos de ejemplo puros
        contexto = generador.crear_contexto_ejemplo()
        output_path = os.path.join(output_dir, "Acta_Entrevista_Ejemplo.docx")
        
        success = generador.generar_documento(plantilla_path, contexto, output_path)
    else:
        cita_id, numero_cita = primera_cita
        print(f"📋 Usando cita #{numero_cita} (ID: {cita_id})")
        
        # Generar documento para esta cita
        success = generador.generar_desde_cita(cita_id, plantilla_path, output_dir)
    
    # Mostrar archivos generados
    if success:
        print(f"\n📁 Documentos en {output_dir}:")
        for archivo in os.listdir(output_dir):
            if archivo.endswith('.docx'):
                ruta = os.path.join(output_dir, archivo)
                tamano = os.path.getsize(ruta)
                print(f"  • {archivo} ({tamano:,} bytes)")
    
    generador.cerrar()
    
    if success:
        print("\n🎯 GENERADOR FUNCIONANDO EXITOSAMENTE")
        print("Siguiente paso: Integrar con interfaz Tkinter")
    else:
        print("\n❌ ERROR EN GENERACIÓN")
        print("Revisa los mensajes de error arriba.")

if __name__ == "__main__":
    main()