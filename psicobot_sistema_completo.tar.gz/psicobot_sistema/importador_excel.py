#!/usr/bin/env python3
"""
Importador de datos desde Excel al sistema Psicobot
Lee la hoja 'LLENAR DATA AQUI' y carga en base de datos SQLite
"""

import pandas as pd
import sqlite3
from datetime import datetime
import os

def importar_excel_a_sqlite(excel_path, db_path='psicobot_sistema/psicobot.db'):
    """
    Importa datos del Excel a la base de datos SQLite
    
    Args:
        excel_path: Ruta al archivo Excel
        db_path: Ruta a la base de datos SQLite
    
    Returns:
        dict: Estadísticas de importación
    """
    
    print(f"📥 IMPORTANDO DATOS DESDE: {excel_path}")
    print(f"💾 HACIA BASE DE DATOS: {db_path}")
    print("=" * 50)
    
    # Verificar que existe el archivo
    if not os.path.exists(excel_path):
        print(f"❌ Error: Archivo no encontrado: {excel_path}")
        return None
    
    # Conectar a base de datos
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # Leer Excel
        xl = pd.ExcelFile(excel_path)
        
        # Verificar que existe la hoja 'LLENAR DATA AQUI'
        if 'LLENAR DATA AQUI' not in xl.sheet_names:
            print(f"❌ Error: No se encontró la hoja 'LLENAR DATA AQUI'")
            print(f"   Hojas disponibles: {xl.sheet_names}")
            return None
        
        # Leer la hoja 'LLENAR DATA AQUI'
        df = xl.parse('LLENAR DATA AQUI')
        
        print(f"📊 Datos leídos: {df.shape[0]} filas × {df.shape[1]} columnas")
        
        # Limpiar nombres de columnas (eliminar espacios extra)
        df.columns = [str(col).strip() for col in df.columns]
        
        # Mostrar columnas disponibles
        print("\n📋 COLUMNAS ENCONTRADAS:")
        for i, col in enumerate(df.columns, 1):
            print(f"  {i:2}. {col}")
        
        # Mapeo de columnas Excel a campos SQLite
        mapeo_columnas = {
            'N°': 'numero_cita',
            'FECHA PROGRAMADA DE DILIGENCIA': 'fecha_programada',
            'HORA DE PROGRAMACIÓN': 'hora_programada',
            'ESTADO': 'estado',
            'PERSONA SOLICITANTE': 'persona_solicitante',
            'N° DE CASO O EXPEDIENTE': 'numero_caso',
            'AUTORIDAD SOLICITANTE': 'autoridad_solicitante',
            'MES': 'mes',
            'Nº CG': 'numero_cg',
            'RESPONSABLE DE LA PROGRAMACIÓN - UML': 'responsable_programacion',
            'FECHA DE SOLICITUD': 'fecha_solicitud',
            'VIA DE SOLICITUD (CON OFICIO-TELEFONICAMENTE)': 'via_solicitud',
            'N° OFICIO': 'numero_oficio',
        }
        
        # Preparar datos para inserción
        registros_insertados = 0
        registros_omitidos = 0
        
        for idx, fila in df.iterrows():
            try:
                # Extraer valores usando el mapeo
                datos = {}
                for col_excel, col_db in mapeo_columnas.items():
                    if col_excel in df.columns:
                        valor = fila[col_excel]
                        
                        # Convertir tipos especiales
                        if pd.isna(valor):
                            valor = None
                        elif 'fecha' in col_db.lower() and isinstance(valor, pd.Timestamp):
                            valor = valor.strftime('%Y-%m-%d')
                        elif 'hora' in col_db.lower() and isinstance(valor, (pd.Timestamp, str)):
                            if isinstance(valor, pd.Timestamp):
                                valor = valor.strftime('%H:%M:%S')
                            elif isinstance(valor, str):
                                # Intentar parsear hora como string
                                valor = str(valor).strip()
                        
                        datos[col_db] = valor
                
                # Solo insertar si tiene número de cita
                if datos.get('numero_cita') and not pd.isna(datos['numero_cita']):
                    # Construir query de inserción
                    columnas = ', '.join(datos.keys())
                    placeholders = ', '.join(['?' for _ in datos])
                    valores = tuple(datos.values())
                    
                    query = f"INSERT INTO citas ({columnas}, excel_row_number) VALUES ({placeholders}, ?)"
                    valores_completos = valores + (idx + 2,)  # +2 porque Excel empieza en fila 2 (fila 1 es encabezado)
                    
                    cursor.execute(query, valores_completos)
                    registros_insertados += 1
                    
                    if registros_insertados % 10 == 0:
                        print(f"  📝 Insertados {registros_insertados} registros...")
                else:
                    registros_omitidos += 1
                    
            except Exception as e:
                print(f"  ⚠️  Error en fila {idx + 2}: {e}")
                registros_omitidos += 1
                continue
        
        # Confirmar cambios
        conn.commit()
        
        # Estadísticas finales
        print("\n" + "=" * 50)
        print("📈 ESTADÍSTICAS DE IMPORTACIÓN:")
        print(f"   ✅ Registros insertados: {registros_insertados}")
        print(f"   ⚠️  Registros omitidos: {registros_omitidos}")
        print(f"   📊 Total filas en Excel: {df.shape[0]}")
        
        # Verificar datos insertados
        cursor.execute("SELECT COUNT(*) FROM citas")
        total_db = cursor.fetchone()[0]
        print(f"   💾 Total en base de datos: {total_db}")
        
        # Mostrar algunos ejemplos insertados
        print("\n📄 EJEMPLOS INSERTADOS (primeras 3 citas):")
        cursor.execute("SELECT numero_cita, fecha_programada, persona_solicitante, numero_caso FROM citas LIMIT 3")
        ejemplos = cursor.fetchall()
        
        for ej in ejemplos:
            print(f"   • Cita #{ej[0]}: {ej[1]} - {ej[2]} (Caso: {ej[3]})")
        
        return {
            'insertados': registros_insertados,
            'omitidos': registros_omitidos,
            'total_excel': df.shape[0],
            'total_db': total_db
        }
        
    except Exception as e:
        print(f"❌ Error durante importación: {e}")
        import traceback
        traceback.print_exc()
        return None
        
    finally:
        conn.close()

def mostrar_citas(db_path='psicobot_sistema/psicobot.db', limite=10):
    """Muestra las citas importadas"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    print(f"\n📅 CITAS IMPORTADAS (primeras {limite}):")
    print("=" * 60)
    
    cursor.execute(f"""
        SELECT id, numero_cita, fecha_programada, hora_programada, 
               persona_solicitante, numero_caso, estado
        FROM citas 
        ORDER BY fecha_programada 
        LIMIT {limite}
    """)
    
    citas = cursor.fetchall()
    
    if not citas:
        print("No hay citas en la base de datos.")
        return
    
    print(f"{'ID':<4} {'Cita#':<6} {'Fecha':<12} {'Hora':<10} {'Solicitante':<25} {'Caso':<15} {'Estado'}")
    print("-" * 90)
    
    for cita in citas:
        id_cita, num, fecha, hora, solicitante, caso, estado = cita
        
        # Formatear valores None
        fecha_str = str(fecha) if fecha else "N/A"
        hora_str = str(hora)[:8] if hora else "N/A"
        solicitante_str = str(solicitante)[:23] + "..." if solicitante and len(str(solicitante)) > 25 else str(solicitante) if solicitante else "N/A"
        caso_str = str(caso)[:12] + "..." if caso and len(str(caso)) > 15 else str(caso) if caso else "N/A"
        estado_str = str(estado) if estado else "N/A"
        
        print(f"{id_cita:<4} {num if num else 'N/A':<6} {fecha_str:<12} {hora_str:<10} {solicitante_str:<25} {caso_str:<15} {estado_str}")
    
    # Total citas
    cursor.execute("SELECT COUNT(*) FROM citas")
    total = cursor.fetchone()[0]
    print(f"\n📊 Total citas en base de datos: {total}")
    
    conn.close()

if __name__ == "__main__":
    # Ruta al Excel que me enviaste
    excel_path = "/root/.openclaw/media/inbound/HOJA_EXCEL_1---1ab7d1a2-b828-4619-a0a5-0f7d98b6f434.xlsx"
    db_path = "psicobot_sistema/psicobot.db"
    
    # Importar datos
    stats = importar_excel_a_sqlite(excel_path, db_path)
    
    if stats:
        # Mostrar citas importadas
        mostrar_citas(db_path)
        
        print("\n🎯 IMPORTACIÓN COMPLETADA EXITOSAMENTE")
        print("Siguiente paso: Crear generador de documentos Word")
    else:
        print("\n❌ IMPORTACIÓN FALLIDA")
        print("Revisa el archivo Excel y vuelve a intentar.")