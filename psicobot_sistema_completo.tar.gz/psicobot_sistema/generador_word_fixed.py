#!/usr/bin/env python3
"""
Generador de documentos Word - Versión corregida
Normaliza nombres de campos para Jinja2
"""

from docxtpl import DocxTemplate
import sqlite3
import os
import re
from datetime import datetime

def normalizar_nombre_campo(campo):
    """
    Normaliza nombre de campo para ser válido en Jinja2
    Convierte 'EL O LA JUEZ' -> 'EL_O_LA_JUEZ'
    """
    # Reemplazar espacios y caracteres especiales con _
    normalizado = re.sub(r'[^a-zA-Z0-9_]', '_', campo.strip())
    # Asegurar que empiece con letra
    if normalizado and not normalizado[0].isalpha():
        normalizado = 'campo_' + normalizado
    return normalizado

def extraer_campos_plantilla(plantilla_path):
    """Extrae y normaliza campos de una plantilla Word"""
    from docx import Document
    
    doc = Document(plantilla_path)
    campos_encontrados = set()
    
    for para in doc.paragraphs:
        text = para.text
        matches = re.findall(r'\{\{([^}]+)\}\}', text)
        for match in matches:
            campos_encontrados.add(match.strip())
    
    # Normalizar todos los campos
    campos_normalizados = {}
    for campo in campos_encontrados:
        normalizado = normalizar_nombre_campo(campo)
        campos_normalizados[normalizado] = campo  # Mapeo: normalizado -> original
    
    return campos_normalizados

class GeneradorDocumentos:
    def __init__(self, db_path='psicobot_sistema/psicobot.db'):
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path)
    
    def crear_contexto_normalizado(self, campos_originales):
        """
        Crea contexto con nombres normalizados para Jinja2
        """
        # Mapeo de campos originales a valores de ejemplo
        valores_ejemplo = {
            'EXPEDIENTE': '2026-00123-PE',
            'HORA_INICIO': '09:00:00',
            'HORA DE TÉRMINO DE DILIGENCIA': '10:30:00',
            'FECHA  AGRAVIADO': '15/04/2026',
            'NOMBRE JUEZ': 'DR. JUAN PÉREZ GARCÍA',
            'EL O LA JUEZ': 'EL JUEZ',
            'NOMBRE DEL JUZGADO': 'JUZGADO DE FAMILIA DE LA MERCED',
            'NOMBRE DEL FISCAL PENAL': 'FISCAL MARÍA LÓPEZ RUIZ',
            'NOMBRE DEL FISCAL FAMILIA': 'FISCAL CARLOS MARTÍNEZ SOTO',
            'PROCEDENCIA DE FISCAL': 'FISCALÍA PENAL DE CHANCHAMAYO',
            'NOMBRE DEL ABOGADO': 'ABG. ROBERTO DÍAZ MENDIETA',
            'CASILLA ELECTRONICA ABOGADO': 'abogado@ejemplo.com',
            'NOMBRE DE PSICOLOGA': 'PSIC. ANA TORRES VARGAS',
            'NOMBRE ESPECIALISTA': 'ESP. LUIS FERNÁNDEZ CASTRO',
            'NOMBRE DENUNCIADO': 'MANUEL GUTIÉRREZ ROJAS',
            'INICICIALES AGRAVIADO': 'M.P.R.',
            'EDAD AGRAVIADO': '32',
            'SEXO AGRAVIADO': 'FEMENINO',
            'DNI DE AGRAVIADO': '87654321',
            'LUGAR DE NACIMIENTO': 'LA MERCED, CHANCHAMAYO',
            'DOMICILIO ACTUAL': 'AV. PROGRESO 123 - LA MERCED',
            'OCUPACION ACTUAL': 'DOCENTE',
            'NRO DE CELULAR': '987654321',
            'NOMBRE DE PADRE': 'PEDRO RAMÍREZ CASTILLO',
            'NOMBRE DE MADRE': 'MARÍA RAMÍREZ SÁNCHEZ',
            'NOMBRE DE ACOMPAÑANTE MENOR': 'SOFÍA GUTIÉRREZ RAMÍREZ',
            'EDAD  DE ACOMPAÑANTE MENOR': '8',
            'DNI  DE ACOMPAÑANTE MENOR': '12345678',
            'ESTADO CIVIL  DE ACOMPAÑANTE MENOR': 'SOLTERA',
            'DOMICILIO DE ACOMPAÑANTE MENOR': 'AV. PROGRESO 123 - LA MERCED',
            'GRADO MENOR': '3er GRADO',
            'NUMERO DE ACOMPAÑANTE MENOR': '987654322',
            'VINCULO DE ACOMPAÑANTE MENOR': 'HIJA',
            'TIPO_DELITO': 'VIOLENCIA FAMILIAR',
            'TIPO_PARTICIPACION': 'VÍCTIMA',
            'TIPO DE DEFENSA': 'DEFENSORÍA PÚBLICA',
            'VINCULO': 'EX PAREJA'
        }
        
        # Crear contexto normalizado
        contexto = {}
        for campo_normalizado, campo_original in campos_originales.items():
            # Usar valor de ejemplo si existe, sino cadena vacía
            valor = valores_ejemplo.get(campo_original, f'[{campo_original}]')
            contexto[campo_normalizado] = valor
        
        return contexto
    
    def generar_documento(self, plantilla_path, contexto, output_path):
        """Genera documento Word"""
        try:
            print(f"📄 Cargando plantilla...")
            doc = DocxTemplate(plantilla_path)
            
            print(f"🔧 Rellenando {len(contexto)} campos...")
            doc.render(contexto)
            
            print(f"💾 Guardando: {output_path}")
            doc.save(output_path)
            
            if os.path.exists(output_path):
                tamano = os.path.getsize(output_path)
                print(f"✅ Documento generado ({tamano:,} bytes)")
                return True
            return False
            
        except Exception as e:
            print(f"❌ Error: {e}")
            return False
    
    def cerrar(self):
        self.conn.close()

def main():
    print("🖨️  GENERADOR DE DOCUMENTOS (VERSIÓN CORREGIDA)")
    print("=" * 50)
    
    # Configuración
    plantilla_path = '/root/.openclaw/media/inbound/A.A.A.A---46e0dd0d-4e26-47a5-aa90-d6fbe89963d7.docx'
    output_dir = '/tmp/psicobot_documentos'
    os.makedirs(output_dir, exist_ok=True)
    
    # Extraer y normalizar campos
    print("🔍 Extrayendo campos de plantilla...")
    campos_originales = extraer_campos_plantilla(plantilla_path)
    
    print(f"📋 Campos encontrados: {len(campos_originales)}")
    print("📝 Campos normalizados:")
    for normalizado, original in sorted(campos_originales.items())[:10]:  # Mostrar primeros 10
        print(f"  • {original} -> {normalizado}")
    
    if len(campos_originales) > 10:
        print(f"  ... y {len(campos_originales) - 10} más")
    
    # Crear generador
    generador = GeneradorDocumentos()
    
    # Crear contexto normalizado
    contexto = generador.crear_contexto_normalizado(campos_originales)
    
    # Generar documento
    output_path = os.path.join(output_dir, "Acta_Entrevista_Generada.docx")
    success = generador.generar_documento(plantilla_path, contexto, output_path)
    
    generador.cerrar()
    
    if success:
        print(f"\n🎯 ¡DOCUMENTO GENERADO EXITOSAMENTE!")
        print(f"📍 Ubicación: {output_path}")
        
        # Mostrar tamaño
        tamano = os.path.getsize(output_path)
        print(f"📏 Tamaño: {tamano:,} bytes ({tamano/1024:.1f} KB)")
        
        # Verificar que es un documento Word válido
        if output_path.endswith('.docx'):
            print("✅ Formato: .docx (Word 2007+)")
        
        print("\n🚀 Siguiente paso: Integrar con base de datos real")
    else:
        print("\n❌ Error en generación")

if __name__ == "__main__":
    main()